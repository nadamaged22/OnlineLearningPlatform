package com.example.finalonlinelearning.Entities;

import javax.json.bind.annotation.JsonbCreator;
import javax.json.bind.annotation.JsonbProperty;

public class Course {
    private String name;
    private String category;
    private String capacity;
    private String Status;
    private int duration;
    private int enrolledStudents;
    private AddedBy AddedBY;
    private String _id;
    private String createdAt;
    private String updatedAt;
    private Integer __v;


    // Default constructor
    public Course() {
    }

    // Constructors
    @JsonbCreator
    public Course(@JsonbProperty("name") String name,
                  @JsonbProperty("category") String category,
                  @JsonbProperty("capacity") String capacity,
                  @JsonbProperty("status") String Status,
                  @JsonbProperty("duration") int duration,
                  @JsonbProperty("enrolledStudnets") int enrolledStudents,
                  @JsonbProperty("AddedBY") AddedBy AddedBY,
                  @JsonbProperty("_id") String _id,
                  @JsonbProperty("createdAt") String createdAt,
                  @JsonbProperty("updatedAt") String updatedAt,
                  @JsonbProperty(" __v") Integer __v){
        this.name = name;
        this.category = category;
        this.capacity = capacity;
        this.Status = Status;
        this.duration = duration;
        this.enrolledStudents = enrolledStudents;
        this.AddedBY = AddedBY;
        this._id = _id;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.__v = __v;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return Status;
    }
    public Integer get__v() {
        return __v;
    }

    public void setName(Integer __v) {
        this.__v = __v;
    }
    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getEnrolledStudents() {
        return enrolledStudents;
    }

    public void setEnrolledStudents(int enrolledStudents) {
        this.enrolledStudents = enrolledStudents;
    }

    public AddedBy getAddedBY() {
        return AddedBY;
    }

    public void setAddedBY(AddedBy addedBY) {
        this.AddedBY = addedBY;
    }



    public static class AddedBy {
        private String id;
        private String email;

        public AddedBy() {
        }

        @JsonbCreator
        public AddedBy(@JsonbProperty("id") String id,
                       @JsonbProperty("email") String email) {
            this.id = id;
            this.email = email;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }
}
